# Module 2: Paw-sitive Vibes

def purr_therapy():
    print('Purr... Purr... Translation: Everything will be okay.')
