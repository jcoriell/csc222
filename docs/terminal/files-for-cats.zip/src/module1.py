# Module 1: Cat Wisdom

def meow_generator():
    print('Meow meow meow. Translation: Feed me.')
