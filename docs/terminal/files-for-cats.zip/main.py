# Script to appease the feline overlords.
print('Hello, Cats of the Internet!')